/*const worker = new Worker('./worker.js', {
  workerData: {
    url,
    time,
    proxyFile,
    userAgents,
  },
});*/

worker.onmessage = function (event) {
  const data = event.data;

  if (data.type === 'progress') {
    // Update the progress bar.
  } else if (data.type === 'complete') {
    // The attack is complete.
  } else if (data.type === 'error') {
    // An error occurred.
  }
};

worker.postMessage({
  type: 'start',
});