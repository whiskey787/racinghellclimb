# 🚀 DDOS_COLLECT_BY_ELSTARO 🚀

# Tree
* [Read this Pls](#plz-%EF%B8%8F) 
* [T.O.S](#TOS)

# Plz ♥️
It would help me a lot if you give a star ⭐ to this repository.<br>
One star from you = more desire to continue updating Leak script and el staro will create many script ddos tool free for u

# COLLECT METHOD
- [x] Open Source
- [x] Stable
- [x] Simple
- [x] Methods for Layer 4 and 7
- [x] Bypass (CF, OVH, Etc)  
- The source is collect of many repository script

# JUST PENTEST YOUR WEBSITE DONT ATTACK GOV WEBSITE!

# Leaked and no leaked script

# TOS:
```sh
Do not attack government pages (.gov/.gob), educational pages (.edu) or the United States Department of Defense (.mil), 
STARS X CYBER TEAM is not responsible for the damage caused by the attacks. 
remember: you are responsible for the attacks since this tool was created for educational purposes
```
